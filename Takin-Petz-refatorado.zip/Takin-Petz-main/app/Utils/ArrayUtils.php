<?php

namespace App\Utils;

class ArrayUtils
{
    /**
     * @param array $array
     * @param string $key
     * @param mixed $default
     * @return mixed
     */
    public static function get($array, $key, $default = null)
    {
        return isset($array[$key]) ? $array[$key] : $default;
    }

    /**
     * @param array $array
     * @param array $keys
     * @return array
     */
    public static function only($array, $keys)
    {
        return array_intersect_key($array, array_flip($keys));
    }

    /**
     * @param mixed $values
     * @return array
     */
    public static function toInts($values)
    {
        return array_values(array_map('intval', array_filter((array)$values, 'is_scalar')));
    }
}

<?php

namespace App\Utils;

use App\Core\Model;

class ModelUtils
{
    /**
     * @param Model[] $models
     * @return int[]
     */
    public static function getIds($models)
    {
        return array_map(function (Model $Model) {
            return $Model->getId();
        }, $models);
    }

    /**
     * @param Model[] $models
     * @param string $attribute
     * @return array
     */
    public static function pluck($models, $attribute)
    {
        return array_map(function (Model $Model) use ($attribute) {
            return $Model->$attribute;
        }, $models);
    }

    /**
     * @param Model[] $models
     * @param int $id
     * @return Model|null
     */
    public static function findById($models, $id)
    {
        foreach ($models as $Model) {
            if ($Model->getId() === (int)$id) {
                return $Model;
            }
        }
        return null;
    }
}

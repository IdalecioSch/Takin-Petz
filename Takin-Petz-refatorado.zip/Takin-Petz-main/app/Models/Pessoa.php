<?php

namespace App\Models;

use App\Core\Model;

class Pessoa extends Model
{
}

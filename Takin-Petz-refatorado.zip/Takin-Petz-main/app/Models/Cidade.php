<?php

namespace App\Models;

use App\Core\Model;

class Cidade extends Model
{
}
